# yt-comment-hider

This Chrome extension adds a toggle "Comments?" button to YouTube video pages, allowing users to easily hide or reveal the comment section with a single click.